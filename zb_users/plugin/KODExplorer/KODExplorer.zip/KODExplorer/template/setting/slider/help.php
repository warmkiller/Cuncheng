<div class='h1'><i class="font-icon icon-question"></i><?php echo $L['setting_help'];?>
<div class="section">
	<div class="content">
		<?php include(LANGUAGE_PATH.LANGUAGE_TYPE.'/help.html');?>
	</div>
</div>
