<div class='h1'><i class="font-icon icon-info-sign"></i><?php echo $L['setting_about'];?></div>
<div class="section">
	<div class="content">
		<?php include(LANGUAGE_PATH.LANGUAGE_TYPE.'/about.html');?>
	</div>
</div>
